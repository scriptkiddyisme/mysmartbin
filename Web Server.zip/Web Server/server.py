from flask import Flask, render_template, jsonify, request,Response, session, redirect, url_for
import mysql.connector
import sys

import json
import numpy
import datetime
import decimal
import os

import gevent
import gevent.monkey
from gevent.pywsgi import WSGIServer

from geopy.geocoders import Nominatim

from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient

gevent.monkey.patch_all()

class GenericEncoder(json.JSONEncoder):

    def default(self, obj):
        if isinstance(obj, numpy.generic):
            return numpy.asscalar(obj)
        elif isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, decimal.Decimal):
            return float(obj)
        else:
            return json.JSONEncoder.default(self, obj)

def data_to_json(data):
    json_data = json.dumps(data,cls=GenericEncoder)
    return json_data

def connect_to_mysql(host,user,password,database):
    try:
        cnx = mysql.connector.connect(host=host,user=user,password=password,database=database)

        cursor = cnx.cursor()
        print("Successfully connected to database!")

        return cnx,cursor

    except:
        print(sys.exc_info()[0])
        print(sys.exc_info()[1])

        return None

def fetch_fromdb_as_json(cnx,cursor,sql):

    try:
        cursor.execute(sql)
        row_headers=[x[0] for x in cursor.description]
        results = cursor.fetchall()
        data = []
        for result in results:
            data.append(dict(zip(row_headers,result)))

        data_reversed = data[::-1]

        data = {'data':data_reversed}

        return data_to_json(data)

    except:
        print(sys.exc_info()[0])
        print(sys.exc_info()[1])
        return None

app = Flask(__name__)
app.secret_key = 'You cannot guess this...'

@app.route("/")
def home():
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the home page
        return render_template('index.html', username=session['username'])
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

@app.route("/managebin")
def managebin():
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the manage bin page
        host='***************.us-east-1.rds.amazonaws.com'; user='mysmartbin_user'; password='Notkey7188!'; database='mysmartbin';
        sql="SELECT b.bin_id,b.name,b.latitude,b.longitude,b.location,ROUND(AVG(lb.percentage),3) FROM bin b, latest_bin_fullness lb WHERE b.bin_id = lb.bin_id GROUP BY bin_id UNION SELECT b.bin_id,b.name,b.latitude,b.longitude,b.location,0 FROM bin b, latest_bin_fullness lb WHERE b.bin_id NOT IN (SELECT bin_id from latest_bin_fullness);"
        cnx,cursor = connect_to_mysql(host,user,password,database)
        cursor.execute(sql)
        results = cursor.fetchall()
        json_data = data_to_json(results)
        loaded_r = json.loads(json_data)

        return render_template('bin.html', username=session['username'], bins=loaded_r)
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

@app.route("/authenticate",methods = ['POST', 'GET'])
def login():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username" and "password" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        db = mysql.connector.connect(user='mysmartbin_user',password='Notkey7188!',host='***************.us-east-1.rds.amazonaws.com',database='mysmartbin')
        cursor = db.cursor()
        sql = 'SELECT * FROM accounts WHERE username = %(username)s AND password = %(password)s'
        cursor.execute(sql,{'username':username,'password':password})
        account = cursor.fetchone()
        db.close()
        # If account exists in accounts table in out database
        if account:
            # Create session data, we can access this data in other routes
            session['loggedin'] = True
            session['id'] = account[0]
            session['username'] = account[1]
            # Redirect to home page
            print("[INFO] Admin user authenticated...")
            return render_template('index.html', username=account[1])
        else:
            # Account doesnt exist or username/password incorrect
            msg = 'Incorrect username/password!'
    # Show the login form with message (if any)
    return render_template('login.html', msg=msg)

@app.route('/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return redirect(url_for('login'))

@app.route('/api/bin/update',methods = ['POST', 'GET'])
def binupdate():
    if request.method == 'POST':
       try:
           bin_name = request.form['bin-name']
           longitude = request.form['longitude']
           latitude = request.form['latitude']
           bin_id = request.form['bin-id']

           geolocator = Nominatim(user_agent="IoTisFun")
           location = geolocator.reverse(latitude+","+longitude).address

           host='***************.us-east-1.rds.amazonaws.com'; user='mysmartbin_user'; password='Notkey7188!'; database='mysmartbin';
           sql="UPDATE bin SET name=%(bin_name)s, longitude=%(longitude)s, latitude=%(latitude)s, location=%(location)s WHERE bin_id=%(bin_id)s"
           cnx,cursor = connect_to_mysql(host,user,password,database)
           cursor.execute(sql, {'bin_name':bin_name,'longitude':longitude,'latitude':latitude,'location':location,'bin_id':bin_id})
           cnx.commit()
       except:
           print(sys.exc_info()[0])
           print(sys.exc_info()[1])
       return redirect(url_for('managebin'))

@app.route('/api/bin/status',methods = ['POST', 'GET'])
def binstatus():
    if request.method == 'POST':
       try:
           host='***************.us-east-1.rds.amazonaws.com'; user='mysmartbin_user'; password='Notkey7188!'; database='mysmartbin';
           sql="SELECT b.bin_id,b.name,b.latitude,b.longitude,b.location,ROUND(AVG(lb.percentage),3) AS fullness FROM bin b, latest_bin_fullness lb WHERE b.bin_id = lb.bin_id GROUP BY bin_id UNION SELECT b.bin_id,b.name,b.latitude,b.longitude,b.location,0 FROM bin b, latest_bin_fullness lb WHERE b.bin_id NOT IN (SELECT bin_id from latest_bin_fullness);"
           cnx,cursor = connect_to_mysql(host,user,password,database)
           json_data = fetch_fromdb_as_json(cnx,cursor,sql)
           loaded_r = json.loads(json_data)
           return jsonify(loaded_r)
       except:
           print(sys.exc_info()[0])
           print(sys.exc_info()[1])

@app.route('/api/bin/usage',methods = ['POST', 'GET'])
def binusage():
    if request.method == 'GET':
       try:
           host='***************.us-east-1.rds.amazonaws.com'; user='mysmartbin_user'; password='Notkey7188!'; database='mysmartbin';
           sql="SELECT CONCAT(DATE(timestamp),CONCAT(' ',CONCAT(HOUR(timestamp), ':00'))) AS time, COUNT(*) AS 'items' FROM bin_fullness WHERE timestamp BETWEEN '2012-02-07' AND NOW() GROUP BY HOUR(timestamp)"
           cnx,cursor = connect_to_mysql(host,user,password,database)
           cursor.execute(sql)
           usage = cursor.fetchall()

           usage_dict = {'time': [], 'items': []}

           if usage:
               for row in usage:
                   usage_dict['time'].append(row[0])
                   usage_dict['items'].append(row[1])

           return jsonify(usage_dict)
       except:
           print(sys.exc_info()[0])
           print(sys.exc_info()[1])

@app.route('/api/bin/delete',methods = ['POST', 'GET'])
def bindelete():
    if request.method == 'POST':
       try:
           bin_id = request.form['bin-id']
           host='***************.us-east-1.rds.amazonaws.com'; user='mysmartbin_user'; password='Notkey7188!'; database='mysmartbin';
           sql="DELETE FROM bin WHERE bin_id=%(bin_id)s"
           cnx,cursor = connect_to_mysql(host,user,password,database)
           cursor.execute(sql, {'bin_id':bin_id})
           cnx.commit()
       except:
           print(sys.exc_info()[0])
           print(sys.exc_info()[1])
       return redirect(url_for('managebin'))

@app.route('/api/bin/location',methods = ['POST', 'GET'])
def binlocation():
    if request.method == 'POST':
       try:
           host='***************.us-east-1.rds.amazonaws.com'; user='mysmartbin_user'; password='Notkey7188!'; database='mysmartbin';
           sql="SELECT latitude, longitude, location FROM bin"
           cnx,cursor = connect_to_mysql(host,user,password,database)
           cursor.execute(sql)
           location = cursor.fetchall()

           location_dict = {'location':[]}

           if location:
               for row in location:
                   temp = []
                   temp.append(row[0])
                   temp.append(row[1])
                   temp.append(row[2])
                   location_dict['location'].append(temp)

           return jsonify(location_dict)
       except:
           print(sys.exc_info()[0])
           print(sys.exc_info()[1])

@app.route('/api/bin/open',methods = ['POST', 'GET'])
def binopen():
    if request.method == 'POST':
       try:
           bin_id = request.form['bin-id']
           host="***************.us-east-1.rds.amazonaws.com"
           rootCAPath = os.path.join("certs", "rootca.pem")
           certificatePath = os.path.join("certs", "certificate.pem.crt")
           privateKeyPath = os.path.join("certs", "private.pem.key")

           my_rpi = AWSIoTMQTTClient("Pub-WebServer")
           my_rpi.configureEndpoint(host, 8883)
           my_rpi.configureCredentials(rootCAPath, privateKeyPath, certificatePath)

           my_rpi.configureOfflinePublishQueueing(-1)  # Infinite offline Publish queueing
           my_rpi.configureDrainingFrequency(2)  # Draining: 2 Hz
           my_rpi.configureConnectDisconnectTimeout(10)  # 10 sec
           my_rpi.configureMQTTOperationTimeout(5)  # 5 sec

           # Connect and subscribe to AWS IoT
           my_rpi.connect()

           my_rpi.publish("bin/"+bin_id+"/action", "open", 1)

           data = {
              'title' : 'Status of Bin',
              'status' : 'Open'
           }

           return jsonify(data)
       except:
           print(sys.exc_info()[0])
           print(sys.exc_info()[1])
           data = {
              'title' : 'Status of Bin',
              'status' : 'Failed'
           }

           return jsonify(data)

@app.route('/api/bin/close',methods = ['POST', 'GET'])
def binclose():
    if request.method == 'POST':
       try:
           bin_id = request.form['bin-id']
           host="***************.us-east-1.rds.amazonaws.com"
           rootCAPath = os.path.join("certs", "rootca.pem")
           certificatePath = os.path.join("certs", "certificate.pem.crt")
           privateKeyPath = os.path.join("certs", "private.pem.key")

           my_rpi = AWSIoTMQTTClient("Pub-WebServer")
           my_rpi.configureEndpoint(host, 8883)
           my_rpi.configureCredentials(rootCAPath, privateKeyPath, certificatePath)

           my_rpi.configureOfflinePublishQueueing(-1)  # Infinite offline Publish queueing
           my_rpi.configureDrainingFrequency(2)  # Draining: 2 Hz
           my_rpi.configureConnectDisconnectTimeout(10)  # 10 sec
           my_rpi.configureMQTTOperationTimeout(5)  # 5 sec

           # Connect and subscribe to AWS IoT
           my_rpi.connect()

           my_rpi.publish("bin/"+bin_id+"/action", "close", 1)

           data = {
              'title' : 'Status of Bin',
              'status' : 'Close'
           }

           return jsonify(data)
       except:
           print(sys.exc_info()[0])
           print(sys.exc_info()[1])
           data = {
              'title' : 'Status of Bin',
              'status' : 'Failed'
           }

           return jsonify(data)

if __name__ == '__main__':
   try:
        print('Server waiting for requests')
        http_server = WSGIServer(('0.0.0.0', 80), app)
        app.debug = True
        http_server.serve_forever()
   except:
        print("Exception")
